 <?php
 
 session_start();
 error_reporting(0);
 
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $db = "demos";

 $connect = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $connect -> error);

 ?>