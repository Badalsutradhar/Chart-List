<!DOCTYPE html>
<html>
	<head>
		<title>ChartJS - Doughnut</title>
		<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
		<script type="text/javascript" src="js/Chart.js"></script>
		<script type="text/javascript" src="js/script.js"></script>
	</head>
	<body>
		<canvas id="mycanvas" width="256" height="256"></canvas>
	</body>
</html>